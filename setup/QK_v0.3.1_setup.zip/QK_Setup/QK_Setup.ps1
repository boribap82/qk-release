﻿# QK 수량산출 - 설치 / 제거 (PowerShell 5.1 · 이 파일은 UTF-8 BOM · backtick 을 쓰지 않는다)
#   설치: QK_Setup.bat            (또는 powershell -ExecutionPolicy Bypass -File QK_Setup.ps1)
#   제거: QK_Uninstall.bat        (= -Uninstall)
#   설치 자리 %APPDATA%\QK\ : QK.xlam(로더) · v<판>\QK_v<판>.xlam · library\team · current.txt · settings.ini
#   엑셀 등록(현재 사용자만 · HKCU):
#     ...\Office\16.0\Excel\Options                         OPEN(n) = "%APPDATA%\QK\QK.xlam"  (추가기능 자동 로드)
#     ...\Office\16.0\Excel\Security\Trusted Locations\QK   Path = %APPDATA%\QK\ · AllowSubfolders = 1  (매크로 경고 없이)
#   제거는 이 둘과 프로그램 파일만 지운다. 사용자 라이브러리(library\user)는 남긴다.
#   -NoRegistry : 파일만 놓고 레지스트리는 건드리지 않는다(시험용)
param(
    [switch]$Uninstall,
    [string]$Root = (Join-Path $env:APPDATA 'QK'),
    [switch]$NoRegistry,
    [string]$UpdateUrl = 'https://raw.githubusercontent.com/boribap82/qk-release/main/latest.json'
)
$ErrorActionPreference = 'Stop'
$Src = $PSScriptRoot
$OfficeKey = 'HKCU:\Software\Microsoft\Office\16.0\Excel'
$OptKey = Join-Path $OfficeKey 'Options'
$TrustKey = Join-Path $OfficeKey 'Security\Trusted Locations\QK'
$Loader = Join-Path $Root 'QK.xlam'
$Utf8 = New-Object System.Text.UTF8Encoding($false)

function Say([string]$m) { Write-Host $m }
function Put([string]$path, [string]$text) { [System.IO.File]::WriteAllText($path, $text, $Utf8) }

function Stop-IfExcel {
    if (Get-Process -Name EXCEL -ErrorAction SilentlyContinue) {
        Say '엑셀이 켜져 있습니다. 엑셀을 모두 닫은 뒤 다시 실행하십시오. (아무것도 바꾸지 않았습니다)'
        exit 2
    }
}

function Get-QkOpenNames {
    $names = @()
    if (-not (Test-Path $OptKey)) { return $names }
    $props = Get-ItemProperty -Path $OptKey
    foreach ($p in $props.PSObject.Properties) {
        if ($p.Name -match '^OPEN\d*$' -and ([string]$p.Value) -like ('*' + $Loader + '*')) { $names += $p.Name }
    }
    return $names
}

function Register-Excel {
    if (-not (Test-Path $OfficeKey)) { throw ('엑셀 16.0 설정 자리가 없습니다: ' + $OfficeKey) }
    if (-not (Test-Path $OptKey)) { New-Item -Path $OptKey -Force | Out-Null }
    $have = Get-QkOpenNames
    if ($have.Count -eq 0) {
        $props = Get-ItemProperty -Path $OptKey
        $used = @($props.PSObject.Properties | Where-Object { $_.Name -match '^OPEN\d*$' } | ForEach-Object { $_.Name })
        $name = 'OPEN'
        $i = 1
        while ($used -contains $name) { $name = 'OPEN' + $i; $i++ }
        New-ItemProperty -Path $OptKey -Name $name -Value ('"' + $Loader + '"') -PropertyType String -Force | Out-Null
        Say ('추가기능 등록: ' + $name + ' = ' + $Loader)
    } else {
        Say ('추가기능 등록 이미 있음: ' + ($have -join ','))
    }
    New-Item -Path $TrustKey -Force | Out-Null
    New-ItemProperty -Path $TrustKey -Name 'Path' -Value ($Root + '\') -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $TrustKey -Name 'AllowSubfolders' -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $TrustKey -Name 'Description' -Value 'QK' -PropertyType String -Force | Out-Null
    Say ('신뢰할 수 있는 위치: ' + $Root + '\ (하위 폴더 포함)')
}

function Unregister-Excel {
    foreach ($n in (Get-QkOpenNames)) {
        Remove-ItemProperty -Path $OptKey -Name $n
        Say ('추가기능 등록 지움: ' + $n)
    }
    # 뒤에 남은 OPENn 이 빈 번호 뒤로 밀려 있으면 앞으로 당긴다(엑셀은 OPEN, OPEN1, ... 을 차례로 읽는다)
    if (Test-Path $OptKey) {
        $props = Get-ItemProperty -Path $OptKey
        $vals = @()
        foreach ($p in $props.PSObject.Properties) {
            if ($p.Name -match '^OPEN(\d*)$') {
                $k = 0
                if ($Matches[1] -ne '') { $k = [int]$Matches[1] }
                $vals += New-Object PSObject -Property @{ K = $k; Name = $p.Name; Value = [string]$p.Value }
            }
        }
        $vals = @($vals | Sort-Object K)
        for ($i = 0; $i -lt $vals.Count; $i++) {
            $want = 'OPEN'
            if ($i -gt 0) { $want = 'OPEN' + $i }
            if ($vals[$i].Name -ne $want) {
                Remove-ItemProperty -Path $OptKey -Name $vals[$i].Name
                New-ItemProperty -Path $OptKey -Name $want -Value $vals[$i].Value -PropertyType String -Force | Out-Null
                Say ('번호 당김: ' + $vals[$i].Name + ' -> ' + $want)
            }
        }
    }
    if (Test-Path $TrustKey) {
        Remove-Item -Path $TrustKey -Recurse -Force
        Say '신뢰할 수 있는 위치 QK 지움'
    }
}

function Install-QK {
    Stop-IfExcel
    $ver = ([System.IO.File]::ReadAllText((Join-Path $Src 'VERSION.txt'))).Trim()
    $body = Join-Path $Src ('v' + $ver + '\QK_v' + $ver + '.xlam')
    if (-not (Test-Path $body)) { throw ('설치 꾸러미에 본체가 없습니다: ' + $body) }
    New-Item -ItemType Directory -Force -Path $Root, (Join-Path $Root ('v' + $ver)), (Join-Path $Root 'library\team'), (Join-Path $Root 'library\user') | Out-Null
    Copy-Item (Join-Path $Src 'QK.xlam') $Loader -Force
    Copy-Item $body (Join-Path $Root ('v' + $ver)) -Force
    # 팀 라이브러리: 꾸러미 판이 더 새것일 때만 바꾸고 옛 판은 team_<판> 으로 남긴다
    $libSrc = Join-Path $Src 'library\team'
    $libDst = Join-Path $Root 'library\team'
    $newL = ([System.IO.File]::ReadAllText((Join-Path $libSrc 'LIBVERSION'))).Trim()
    $curL = ''
    if (Test-Path (Join-Path $libDst 'LIBVERSION')) { $curL = ([System.IO.File]::ReadAllText((Join-Path $libDst 'LIBVERSION'))).Trim() }
    if ($curL -eq '' -or ([version]$newL) -gt ([version]$curL)) {
        if ($curL -ne '') { Copy-Item $libDst (Join-Path $Root ('library\team_' + $curL)) -Recurse -Force }
        Copy-Item (Join-Path $libSrc '*') $libDst -Force
        Say ('팀 라이브러리 ' + $newL)
    } else {
        Say ('팀 라이브러리 그대로(' + $curL + ')')
    }
    Put (Join-Path $Root 'current.txt') $ver
    $ini = Join-Path $Root 'settings.ini'
    $nl = [string][char]13 + [string][char]10
    if (-not (Test-Path $ini)) { Put $ini ('update_url=' + $UpdateUrl + $nl + 'check_updates=1' + $nl) }
    Get-ChildItem -Path $Root -Recurse -File | Unblock-File
    if (-not $NoRegistry) { Register-Excel } else { Say '레지스트리는 건드리지 않음(-NoRegistry)' }
    Put (Join-Path $Root 'install.log') ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' install v' + $ver + ' lib ' + $newL + ' registry=' + (-not $NoRegistry))
    Say ('설치 끝: QK v' + $ver + ' -> ' + $Root + ' · 엑셀을 켜면 리본에 「수량산출」 탭이 보입니다.')
}

function Uninstall-QK {
    Stop-IfExcel
    if (-not $NoRegistry) { Unregister-Excel } else { Say '레지스트리는 건드리지 않음(-NoRegistry)' }
    if (Test-Path $Root) {
        foreach ($item in (Get-ChildItem -Path $Root -Force)) {
            if ($item.Name -eq 'library') {
                foreach ($lib in (Get-ChildItem -Path $item.FullName -Force)) {
                    if ($lib.Name -ne 'user') { Remove-Item $lib.FullName -Recurse -Force }
                }
            } else {
                Remove-Item $item.FullName -Recurse -Force
            }
        }
    }
    Say ('제거 끝: 프로그램·등록을 지웠습니다. 사용자 라이브러리는 남겼습니다: ' + (Join-Path $Root 'library\user'))
}

try {
    if ($Uninstall) { Uninstall-QK } else { Install-QK }
    exit 0
} catch {
    Say ('실패: ' + $_.Exception.Message)
    exit 1
}
