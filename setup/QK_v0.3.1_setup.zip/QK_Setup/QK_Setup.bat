@echo off
rem QK setup launcher (ASCII only). Close Excel first.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0QK_Setup.ps1" %*
pause
