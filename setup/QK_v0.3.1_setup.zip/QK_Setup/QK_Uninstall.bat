@echo off
rem QK uninstall launcher (ASCII only). Close Excel first. User library is kept.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0QK_Setup.ps1" -Uninstall %*
pause
